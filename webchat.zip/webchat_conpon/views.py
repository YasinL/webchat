from  core.wx.wx_interactive import weixin_main
from  core.viewshop.shop_sel_lib import shop_sel_lib_list as index