from django.apps import AppConfig


class WebchatConponConfig(AppConfig):
    name = 'webchat_conpon'
